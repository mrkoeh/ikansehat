<center><h3>Form Konsultasi</h3></center>
<form action="<?php echo base_url();?>Konsultasi/diagnosa" method="post" id="myform">
<input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">
<h3>Pilih Jenis Ikan:</h3>
<table  border="0" cellpadding="5" cellspacing="0">

<?php 
	$no=1;
	foreach($ikans->result_array() as $i) {?>
	<tr>
		<td width="20px;"><?php echo $no; ?>. </td>
		<td width="200px;"><?php echo $i['nama_ikan'];?></td>
		<td><input type="radio" value="<?php echo $i['id'];?>" name="id_ikan"> &nbsp; Pilih</td>
	</tr>
<?php $no++; } ?>
	
</table>
<hr>
<br>
<h3>Pilih Gejala:</h3>
<table align="center" width="650" border="1" cellspacing="0" cellpadding="10">
	<tr>
		<td>Kode</td>
		<td>Gejala</td>
		<td>Pilih</td>
	</tr>
		<?php foreach($gejalas->result_array() as $g ){ ?>
	<tr>
		<td align="center">
			<?php echo $g['kode'];?>
		</td>
		<td align="left">
			<?php echo $g['nama_gejala'];?>
		</td>
		<td align="center">
			<input type="checkbox" value="<?php echo $g['kode'];?>" name="gejala[]">
		</td>
	</tr>
	<?php } ?>

</table><br>
<center>
<?php echo $pagination;?><br><br>
<input type="submit" value="diagnosa"></center>
</form>