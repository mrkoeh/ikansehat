<div class='alert alert-block alert-success'>
    Selamat datang <strong>Admin</strong> Di Halaman Admin.
</div>