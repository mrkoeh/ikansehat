<h3><center>Detail Pengetahuan</center></h3>
<h4><?php echo $kode_penyakit; ?> - <?php echo $jenis_penyakit;?></h4>
<?php if($gambar != null) { ?>
<center><img src="<?php echo base_url();?>assets/upload/<?php echo $gambar;?>" class="gambar_p"></center>
<?php }  ?>
<br>
<h4>Gejala Penyakit :</h4>
<?php foreach ($gejalas as $key => $value) {
	
	echo '<b>'.$value['gejala_kode'].'</b>&nbsp;-&nbsp;'.$value['nama_gejala'].'<br>';
}
?>

<br>
<h4>Penanganan Penyakit:</h4>
<?php echo $jenis_solusi; ?>

