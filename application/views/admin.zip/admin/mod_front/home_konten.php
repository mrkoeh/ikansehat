
<table align="center" width="500" cellspacing="0" cellpadding="20">
	<tr align="center">
		<td><img src="<?php echo base_url();?>assets/template/front/images/registericon.png" width="100" height="100"><br><a href="<?php echo base_url();?>HomeDashboard/daftar">Daftar</a></td>
		<td><img src="<?php echo base_url();?>assets/template/front/images/logedinicon.png" width="100" height="100"><br><a href="<?php echo base_url();?>HomeDashboard/login">Login</a></td>
		<td><img src="<?php echo base_url();?>assets/template/front/images/konsultasiicon.png" width="100" height="100"><br><a href="<?php echo base_url();?>Konsultasi/index">Konsultasi</a></td>
		<td><img src="<?php echo base_url();?>assets/template/front/images/printicon.png" width="100" height="100"><br>Cetak</td>
	</tr>
</table>
