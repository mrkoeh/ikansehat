<center><h3>Setting akun</h3></center>
<center><?php echo $this->session->flashdata("k");?> </center>
<form class="login" action="<?php echo base_url();?>Akun/edit_akun" method="post">
	<input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">
	<input type="hidden" name="id" value="<?php echo $user_id;?>">
	<table align="center">
		<tr>
			<td>Nama</td><td>:</td><td><input type="text" name="nama" value="<?php echo $nama;?>" style="width: 300px;"></td>
		</tr>
		<tr>
			<td>Email</td><td>:</td><td><input type="email" name="email" value="<?php echo $email;?>" style="width: 300px;"></td>
		</tr>
		<tr>
			<td>Username</td><td>:</td><td><input type="text" name="username" value="<?php echo $username;?>" readonly="readonly" style="width: 300px;"></td>
		</tr>
		<tr>
			<td>Password</td><td>:</td><td><input type="password" name="password" style="width: 300px;"></td>
		</tr>
		<tr>
			<td colspan="3" align="center"><input type="submit" value="Update"></td>
		</tr>
	</table>
</form>
