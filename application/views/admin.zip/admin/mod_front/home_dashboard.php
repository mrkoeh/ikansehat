<!DOCTYPE html>
<html>
<head>
	<title>Sistem Pakar Diagnosa Penyakit Ikan Tawar</title>
	<link href="<?php echo base_url();?>assets/template/front/style.css" type="text/css" rel="stylesheet">
</head>
<body>
<div class="wrapper">
	<div class="header">
		<div class="logo"><img src="<?php echo base_url();?>assets/template/front/images/logo.png"></div>
		<div class="logotext">Sistem Pakar Penyakit Ikan Tawar</div>

		<div class="form_login">
			<?php if(!$this->session->userdata('username')){ echo "";}else{ ?>
			<p>User login: <b><?php echo $this->session->userdata('nama');?></b> | <a href="<?php echo base_url();?>Cek_login/logout">Logout</a></p>
			<?php } ?>
		</div>
	</div>
	<div class="sidebar">
		<nav>
		    <ul>
		    <li><a href="<?php echo base_url();?>UserDashboard/index">Informasi Penyakit</a></li>
		    <li><a href="<?php echo base_url();?>Konsultasi/index">Konsultasi</a></li>
		    <li><a href="<?php echo base_url();?>Konsultasi/riwayat">Riwayat Konsultasi</a></li>
		    <li><a href="<?php echo base_url();?>Akun/index">Setting Akun</a></li>
		    </ul>
		</nav>

	</div>
	<div class="konten">
			<?php echo $contents; ?>
	</div>
	<div class="footer">
		<div class="copyright">copyright &copy; <?php echo date('Y');?> <br> Sistem pakar online penyakit ikan tawar</div>
	</div>
</div>
</body>
</html>